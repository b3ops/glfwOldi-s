# GLFW-Instancing-with-camera-

g++ -Wall -g -o run inst.cpp shader.cpp -lGLEW -lglfw3 -lGL -lGLU -lX11 -lXi -lXrandr -lXxf86vm -lXinerama -lXcursor -lrt -lm -pthread -ldl

Thanks to learnOpenGL.com for tutorials and examples.. i changed from the glad.h to glew.h just because i had it already set up..
