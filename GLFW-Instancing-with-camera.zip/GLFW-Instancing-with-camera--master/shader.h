#ifndef SHADER_HPP
#define SHADER_HPP

GLuint LoadShaders( const char * vertexFilePath,
    const char * fragmentFilePath);
#endif
